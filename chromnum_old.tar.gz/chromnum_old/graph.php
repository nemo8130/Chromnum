<?php
//error_reporting(E_ALL);
//ini_set('display_errors',1);
//ini_set('display_startup_errors',1);
//error_reporting(-1);

$phpinp=$_POST['phpinp'];
$pass_col1=explode("=",$phpinp);
$colour_ar=array();

	for ($c=0;$c<count($pass_col1);$c++)
	{
	$pass_col2=explode("~",$pass_col1[$c]);
	array_push($colour_ar,$pass_col2[1]);
	}
$qstrphp = trim($_POST['qstrphp']);
$qstrphp = str_replace("tag=&amat=","",$qstrphp);
$qstrphp = str_replace("%0D%0A","|",$qstrphp);
$qstrphp = preg_replace("/\\+{2,}/", "+", $qstrphp);
$fl=explode("|",$qstrphp);
$cnt = count($fl);
$node_count=0;
$points = array();

	for ($i=0;$i<$cnt;$i++)
	{
		if (strlen($fl[$i])>0)
		{ 
		$node_count+=1;
		array_push($points,explode("+",$fl[$i]));
		}
	}
unset($points[$cnt]);
$img = imagecreatetruecolor(900, 900);

$black = imagecolorallocate($img, 0, 0, 0);
$white = imagecolorallocate($img, 0xFF, 0xFF, 0xFF);
$col['red'] = imagecolorallocate($img, 0xFF, 0x00, 0x00); 
$col['green'] = imagecolorallocate($img, 0x00, 0xFF, 0x00);
$col['blue'] = imagecolorallocate($img, 0x00, 0x00, 0xFF);
$col['white'] = imagecolorallocate($img, 255, 255, 255);
$col['yellow']  = imagecolorallocate($img,   255,   255, 0);
$col['silver'] = imagecolorallocate($img,   192,   192, 192);
$col['steelblue'] = imagecolorallocate($img,   70,   130, 180);
$col['hotpink'] = imagecolorallocate($img, 255, 105, 180);
$col['pink'] = imagecolorallocate($img, 255, 192, 203);
$col['orange'] = imagecolorallocate($img, 255, 165, 0);
$col['coral'] = imagecolorallocate($img, 255, 127, 80);
$col['magenta'] = imagecolorallocate ($img,255,0,255);
$col['cyan'] = imagecolorallocate ($img,0,255,255);
$col['black'] = imagecolorallocate ($img,0,0,0);
$col['brown'] = imagecolorallocate ($img,165,42,42);
$col['burlywood'] = imagecolorallocate ($img, 222,184,135);
$col['cadetblue'] = imagecolorallocate ($img,  95,158,160);
$col['chartreuse'] = imagecolorallocate ($img,   127,255,0);
$col['chocolate'] = imagecolorallocate ($img,  210,105,30);
$col['cornflowerblue'] = imagecolorallocate ($img, 100,149,237);
$col['cornsilk'] = imagecolorallocate ($img, 255,248,220);
$col['crimson'] = imagecolorallocate ($img,   220,20,60);
$col['darkblue'] = imagecolorallocate ($img,     0,0,139);
$col['darkcyan'] = imagecolorallocate ($img,   0,139,139);
$col['darkgoldenrod'] = imagecolorallocate ($img,  184,134,11);
$col['darkgray'] = imagecolorallocate ($img, 169,169,169);
$col['darkgreen'] = imagecolorallocate ($img,     0,100,0);
$col['darkgrey'] = imagecolorallocate ($img, 169,169,169);
$col['darkkhaki'] = imagecolorallocate ($img, 189,183,107);
$col['darkmagenta'] = imagecolorallocate ($img,   139,0,139);
$col['darkolivegreen'] = imagecolorallocate ($img,   85,107,47);
$col['darkorange'] = imagecolorallocate ($img,   255,140,0);
$col['darkorchid'] = imagecolorallocate ($img,  153,50,204);
$col['darkred'] = imagecolorallocate ($img,     139,0,0);
$col['darksalmon'] = imagecolorallocate ($img, 233,150,122);
$col['darkseagreen'] = imagecolorallocate ($img, 143,188,143);
$col['darkslateblue'] = imagecolorallocate ($img,   72,61,139);
$col['darkslategray'] = imagecolorallocate ($img,    47,79,79);
$col['darkslategrey'] = imagecolorallocate ($img,    47,79,79);
$col['darkturquoise'] = imagecolorallocate ($img,   0,206,209);
$col['darkviolet'] = imagecolorallocate ($img,   148,0,211);
$col['deeppink'] = imagecolorallocate ($img,  255,20,147);
$col['deepskyblue'] = imagecolorallocate ($img,   0,191,255);
$col['dimgray'] = imagecolorallocate ($img, 105,105,105);
$col['dimgrey'] = imagecolorallocate ($img, 105,105,105);
$col['dodgerblue'] = imagecolorallocate ($img,  30,144,255);
$col['firebrick'] = imagecolorallocate ($img,   178,34,34);
$col['floralwhite'] = imagecolorallocate ($img, 255,250,240);
$col['forestgreen'] = imagecolorallocate ($img,   34,139,34);
$col['fuchsia'] = imagecolorallocate ($img,   255,0,255);
$col['gainsboro'] = imagecolorallocate ($img, 220,220,220);
$col['ghostwhite'] = imagecolorallocate ($img, 248,248,255);
$col['gold'] = imagecolorallocate ($img,   255,215,0);
$col['goldenrod'] = imagecolorallocate ($img,  218,165,32);
$col['gray'] = imagecolorallocate ($img, 128,128,128);
$col['greenyellow'] = imagecolorallocate ($img,  173,255,47);

imagefill($img, 0, 0, $white);
imagearc($img, 449, 449, 800, 800, 0, 0, $black);
imagefilledarc($img, 449, 449, 0, 0, 0, 0, $black, IMG_ARC_PIE);
$x_coord_all = array();
$y_coord_all = array();
	for ($num_dots=0; $num_dots<$node_count;$num_dots++)
	{
	$x_coord = round(350 * cos(deg2rad(360*$num_dots/$node_count)),0) + 449;
	$y_coord = round(350 * sin(deg2rad(360*$num_dots/$node_count)),0) + 449;
	array_push($x_coord_all,$x_coord);
	array_push($y_coord_all,$y_coord);
	}

imagesetthickness($img, 2);

	for ($j=0;$j<$node_count;$j++)
	{
		for ($k=0;$k<$node_count;$k++)
		{
			if ($points[$j][$k]==1)
			{
			imageline($img, $x_coord_all[$j], $y_coord_all[$j], $x_coord_all[$k], $y_coord_all[$k], $black);
			}
			if ($j==$k) 
			{
			break;
			}
		}
	}

$xmid = 450;
$ymid = 450;

	for ($num_dots=0; $num_dots<$node_count;$num_dots++)
	{
	imagefilledarc($img, $x_coord_all[$num_dots], $y_coord_all[$num_dots], 20, 20, 0, 0, $col[$colour_ar[$num_dots]], IMG_ARC_PIE);
	$print_node = $num_dots+1;
		if ($x_coord_all[$num_dots] <= $xmid && $y_coord_all[$num_dots] <= $ymid)
		{
		$print_pos_x= $x_coord_all[$num_dots]-25;
		$print_pos_y= $y_coord_all[$num_dots]-25;
		}
		if ($x_coord_all[$num_dots] >= $xmid && $y_coord_all[$num_dots] <= $ymid)
		{
		$print_pos_x= $x_coord_all[$num_dots]+15;
		$print_pos_y= $y_coord_all[$num_dots]-15;
		}
		if ($x_coord_all[$num_dots] <= $xmid && $y_coord_all[$num_dots] >= $ymid)
		{
		$print_pos_x= $x_coord_all[$num_dots]-15;
		$print_pos_y= $y_coord_all[$num_dots]+15;
		}
		if ($x_coord_all[$num_dots] >= $xmid && $y_coord_all[$num_dots] >= $ymid)
		{
		$print_pos_x= $x_coord_all[$num_dots]+10;
		$print_pos_y= $y_coord_all[$num_dots]+10;
		}
	imagestring($img, 5, $print_pos_x, $print_pos_y, $print_node, $textcolor);
	}


header("Content-type: image/png");
imagepng($img);
imagedestroy($img);
?>
